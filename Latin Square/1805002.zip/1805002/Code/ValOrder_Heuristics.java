import java.util.List;

public class ValOrder_Heuristics {
    public List<Integer> domain;

    public ValOrder_Heuristics(List<Integer> domain){
        this.domain = domain;
    }

    public int getValue(){
        return 0;
    }
}
